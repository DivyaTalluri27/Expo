from rest_framework import serializers
from recycle_app.models import Event

class EventSerializer(serializers.ModelSerializer):
    class Meta:
        model = Event
        fields = ('id',
                 'name',
                 'startDate',
                 'endDate',
                 'status',
                 'registrationCharge',
                 'registrationTax',
                 'registrationTotal',
                 'fileUpload',
                 'description'
                 )