from django.apps import AppConfig


class recycle_appConfig(AppConfig):
    name = 'recycle_app'
