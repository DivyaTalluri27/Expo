from rest_framework.parsers import JSONParser
from django.db import IntegrityError
from . models import Event
from . serializers import EventSerializer
from django.http.response import JsonResponse
from rest_framework.views import APIView
from django.views.generic import TemplateView
from django.views.decorators.csrf import csrf_exempt
# from django.shortcuts import (get_object_or_404)

# Create your views here.
class Event_Register(APIView):
    def post(self,request):
        try:
            register_data=JSONParser().parse(request)
            event_data= Event.objects.create(
                                            name=register_data['name'],
                                            startDate=register_data['startDate'],
                                            endDate=register_data['endDate'],
                                            status=register_data['status'],
                                            registrationCharge=register_data['registrationCharge'],
                                            registrationTax=register_data['registrationTax'],
                                            registrationTotal=register_data['registrationTotal'],
                                            fileUpload=register_data['fileUpload'],
                                            description=register_data['description']
                                            )
            event_data.save()
            return JsonResponse("successfully registered!!",safe=False)

        except IntegrityError:
            return JsonResponse('user of this data is already exist!!',safe=False)

class Event_List(APIView):
    def get(self,request):
        events=Event.objects.all()
        serializer=EventSerializer(events,many=True)
        return JsonResponse(serializer.data,safe=False)

@csrf_exempt
def UserDelete(request,id=0):
    try:
        if request.method=='DELETE':
            event=Event.objects.get(id=id)
            event.delete()
            return JsonResponse('deleted successfully!!',safe=False)
    except Exception:
        return JsonResponse('Id not found!!',safe=False)
        
    
    
    # def delete(self,request,id):
        # delete_event=request.data
        # delete_event=self.get_object(id=id)
         # delete_event = delete_event.objects.filter(pk=id).delete()
        # event=Event.objects.get(id=delete_event["id"])
        # event.delete()
        # return JsonResponse("successfully deleted!!",safe=False)


class Supportedby_Register(APIView):
    def post(self,request):
        try:
            register_data=JSONParser().parse(request)
            supportedby_data= Supportedby.objects.create(
                                            nameofthecompany=register_data['nameofthecompany'],
                                            imgurl=register_data['imgurl']
                                           )
            event_data.save()
            return JsonResponse("successfully registered!!",safe=False)

        except IntegrityError:
            return JsonResponse('user of this data is already exist!!',safe=False)


class Supportedby_List(APIView):
    def get(self,request):
        supportedby=Supportedby.objects.all()
        serializer=EventSerializer(events,many=True)
        return JsonResponse(serializer.data,safe=False)  

@csrf_exempt
def UserDelete(request,id=0):
    try:
        if request.method=='DELETE':
            supportedby=Supportedby.objects.get(id=id)
            supportedby.delete()
            return JsonResponse('deleted successfully!!',safe=False)
    except Exception:
        return JsonResponse('Id not found!!',safe=False)

    


